package Main;
import by.bobruisk.itstep.shop.StoreInterface;
import by.bobruisk.itstep.shop.computer.Stock;

public class Main {

	public static void main(String[] args) {
		Stock stock = new Stock();
		stock.filling();

		StoreInterface storeinterface = new StoreInterface(stock);
		storeinterface.createGUI();
	}
}
