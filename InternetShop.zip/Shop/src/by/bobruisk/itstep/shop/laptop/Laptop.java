package by.bobruisk.itstep.shop.laptop;

import by.bobruisk.itstep.shop.computer.CPU;
import by.bobruisk.itstep.shop.computer.HDD;
import by.bobruisk.itstep.shop.computer.Motherboard;
import by.bobruisk.itstep.shop.computer.RAM;
import by.bobruisk.itstep.shop.computer.VideoCard;

public class Laptop {

	private VideoCard videoCard = new VideoCard();
	private RAM ram = new RAM();
	private HDD hdd = new HDD();
	private Motherboard motherboard = new Motherboard();
	private CPU cpu = new CPU();
	private String name;
	private String images[] = new String[3];
	private String price;

	public VideoCard getVideoCard() {
		return videoCard;
	}

	public void setVideoCard(VideoCard videoCard) {
		this.videoCard = videoCard;
	}

	public RAM getRam() {
		return ram;
	}

	public void setRam(RAM ram) {
		this.ram = ram;
	}

	public HDD getHdd() {
		return hdd;
	}

	public void setHdd(HDD hdd) {
		this.hdd = hdd;
	}

	public Motherboard getMotherboard() {
		return motherboard;
	}

	public void setMotherboard(Motherboard motherboard) {
		this.motherboard = motherboard;
	}

	public CPU getCpu() {
		return cpu;
	}

	public void setCpu(CPU cpu) {
		this.cpu = cpu;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String[] getImages() {
		return images;
	}

	public void setImages(String[] images) {
		this.images = images;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ\n")
				.append("------------------------------------------------------------------------------------------\n")
				.append("Тип процессора").append("..............................")
				.append(this.cpu).append("\n").append("Тип видеокарты")
				.append("..............................").append(this.videoCard).append("\n")
				.append("ОЗУ").append(".....................................................").append(this.ram)
				.append("\n").append("Жесткий диск")
				.append("...................................").append(this.hdd).append("\n")
				.append("Материнская плата").append("........................").append(this.motherboard)
				.append("\n")
				.append("------------------------------------------------------------------------------------------\n")
				.append("Цена").append("...................................................").append(this.price + "руб.");
		return str.toString();
	}
}
