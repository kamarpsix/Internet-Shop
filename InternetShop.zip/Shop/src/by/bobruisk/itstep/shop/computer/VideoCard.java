package by.bobruisk.itstep.shop.computer;

public class VideoCard {

	private String manufacturer;
	private String name;
	private String typeOf;

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTypeOf() {
		return typeOf;
	}

	public void setTypeOf(String typeOf) {
		this.typeOf = typeOf;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append(this.manufacturer).append(" ").append(this.name).append(" ").append(this.typeOf);
		return str.toString();
	}
}
