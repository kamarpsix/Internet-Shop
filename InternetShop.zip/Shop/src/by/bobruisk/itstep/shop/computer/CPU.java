package by.bobruisk.itstep.shop.computer;

public class CPU {

	private String manufacturer;
	private String name;
	private String frequency;

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append(this.manufacturer).append(" ").append(this.name).append(" ").append(this.frequency);
		return str.toString();
	}
}
