package by.bobruisk.itstep.shop.computer;

public class Motherboard {

	private String manufacturer;
	private String name;

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append(this.manufacturer).append(" ").append(this.name);
		return str.toString();
	}
}
