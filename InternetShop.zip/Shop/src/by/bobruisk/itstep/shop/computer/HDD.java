package by.bobruisk.itstep.shop.computer;

public class HDD {

	private String typeOf;
	private String volume;
	private String manufacturer;
	private String name;

	public String getTypeOf() {
		return typeOf;
	}

	public void setTypeOf(String typeOf) {
		this.typeOf = typeOf;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append(this.manufacturer).append(" ").append(this.name).append(" ").append(this.typeOf).append(" ")
				.append(this.volume);
		return str.toString();
	}
}
