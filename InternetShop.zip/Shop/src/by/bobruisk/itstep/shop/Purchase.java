package by.bobruisk.itstep.shop;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class Purchase {

	public void purchase() {

		SpringLayout layout = new SpringLayout();
		JLabel taskOne = new JLabel("Личные данные");
		taskOne.setFont(new Font("Bold", Font.BOLD, 20));
		JLabel taskTwo = new JLabel("Адрес доставки");
		taskTwo.setFont(new Font("Bold", Font.BOLD, 20));
		JLabel taskThree = new JLabel("Вид оплаты");
		taskThree.setFont(new Font("Bold", Font.BOLD, 20));
		JFrame frame = new JFrame("");
		JLabel nameLabel = new JLabel("Имя:");
		JTextField nameField = new JTextField(12);
		JLabel surnameLabel = new JLabel("Фамилия:");
		JTextField surnameField = new JTextField(12);
		JLabel middlenameLabel = new JLabel("Отчество:");
		JTextField middlenameField = new JTextField(12);
		JLabel city = new JLabel("Город:");
		JTextField cityField = new JTextField(12);
		JLabel deliveryAddress = new JLabel("Адрес доставки:");
		JTextField deliveryAddressField = new JTextField(12);
		JLabel phoneNumber = new JLabel("Номер телефона:");
		JTextField phoneNumberField = new JTextField(12);
		phoneNumberField.setText("(+375)");
		JRadioButton radioOne = new JRadioButton("Наличные");
		JRadioButton radioTwo = new JRadioButton("Банковская карта");
		JButton button = new JButton("Оформить заказ");

		ButtonGroup group = new ButtonGroup();
		group.add(radioOne);
		group.add(radioTwo);
		radioOne.setSelected(true);
		frame.add(taskOne);
		frame.add(taskTwo);
		frame.add(taskThree);
		frame.setLayout(layout);
		frame.add(surnameLabel);
		frame.add(surnameField);
		frame.add(nameLabel);
		frame.add(nameField);
		frame.add(middlenameLabel);
		frame.add(middlenameField);
		frame.add(city);
		frame.add(cityField);
		frame.add(deliveryAddress);
		frame.add(deliveryAddressField);
		frame.add(radioOne);
		frame.add(radioTwo);
		frame.add(button);
		frame.add(phoneNumber);
		frame.add(phoneNumberField);

		layout.putConstraint(SpringLayout.WEST, taskOne, 150, SpringLayout.WEST, frame);
		layout.putConstraint(SpringLayout.WEST, surnameLabel, 90, SpringLayout.WEST, frame);
		layout.putConstraint(SpringLayout.NORTH, surnameLabel, 50, SpringLayout.NORTH, frame);
		layout.putConstraint(SpringLayout.WEST, surnameField, 30, SpringLayout.EAST, surnameLabel);
		layout.putConstraint(SpringLayout.NORTH, surnameField, 0, SpringLayout.NORTH, surnameLabel);

		layout.putConstraint(SpringLayout.WEST, nameLabel, 32, SpringLayout.WEST, surnameLabel);
		layout.putConstraint(SpringLayout.NORTH, nameLabel, 30, SpringLayout.NORTH, surnameLabel);
		layout.putConstraint(SpringLayout.WEST, nameField, 30, SpringLayout.EAST, nameLabel);
		layout.putConstraint(SpringLayout.NORTH, nameField, 0, SpringLayout.NORTH, nameLabel);

		layout.putConstraint(SpringLayout.EAST, middlenameLabel, 0, SpringLayout.EAST, nameLabel);
		layout.putConstraint(SpringLayout.NORTH, middlenameLabel, 30, SpringLayout.NORTH, nameLabel);
		layout.putConstraint(SpringLayout.WEST, middlenameField, 30, SpringLayout.EAST, middlenameLabel);
		layout.putConstraint(SpringLayout.NORTH, middlenameField, 0, SpringLayout.NORTH, middlenameLabel);

		layout.putConstraint(SpringLayout.EAST, phoneNumber, 0, SpringLayout.EAST, middlenameLabel);
		layout.putConstraint(SpringLayout.NORTH, phoneNumber, 30, SpringLayout.NORTH, middlenameLabel);
		layout.putConstraint(SpringLayout.WEST, phoneNumberField, 30, SpringLayout.EAST, middlenameLabel);
		layout.putConstraint(SpringLayout.NORTH, phoneNumberField, 30, SpringLayout.NORTH, middlenameLabel);

		layout.putConstraint(SpringLayout.WEST, taskTwo, 150, SpringLayout.WEST, frame);
		layout.putConstraint(SpringLayout.NORTH, taskTwo, 140, SpringLayout.WEST, phoneNumber);
		layout.putConstraint(SpringLayout.EAST, city, 0, SpringLayout.EAST, middlenameLabel);
		layout.putConstraint(SpringLayout.NORTH, city, 50, SpringLayout.NORTH, taskTwo);
		layout.putConstraint(SpringLayout.WEST, cityField, 30, SpringLayout.EAST, city);
		layout.putConstraint(SpringLayout.NORTH, cityField, 0, SpringLayout.NORTH, city);

		layout.putConstraint(SpringLayout.EAST, deliveryAddress, 0, SpringLayout.EAST, city);
		layout.putConstraint(SpringLayout.NORTH, deliveryAddress, 30, SpringLayout.NORTH, city);
		layout.putConstraint(SpringLayout.WEST, deliveryAddressField, 30, SpringLayout.EAST, deliveryAddress);
		layout.putConstraint(SpringLayout.NORTH, deliveryAddressField, 0, SpringLayout.NORTH, deliveryAddress);

		layout.putConstraint(SpringLayout.WEST, taskThree, 160, SpringLayout.WEST, frame);
		layout.putConstraint(SpringLayout.NORTH, taskThree, 50, SpringLayout.NORTH, deliveryAddress);

		layout.putConstraint(SpringLayout.WEST, radioOne, 80, SpringLayout.EAST, frame);
		layout.putConstraint(SpringLayout.NORTH, radioOne, 50, SpringLayout.NORTH, taskThree);
		layout.putConstraint(SpringLayout.WEST, radioTwo, 60, SpringLayout.EAST, radioOne);
		layout.putConstraint(SpringLayout.NORTH, radioTwo, 50, SpringLayout.NORTH, taskThree);

		layout.putConstraint(SpringLayout.WEST, button, 140, SpringLayout.EAST, frame);
		layout.putConstraint(SpringLayout.NORTH, button, 70, SpringLayout.NORTH, radioOne);

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (nameField.getText().trim().length() == 0 || surnameField.getText().trim().length() == 0
						|| middlenameField.getText().trim().length() == 0 || cityField.getText().trim().length() == 0
						|| phoneNumberField.getText().trim().length() == 0
						|| deliveryAddressField.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(frame, "Для оформления заказа заполните все поля!!!",
							"Ошибка ввода данных", JOptionPane.ERROR_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(frame,
							"Ваш заказ успешно оформлен.\nОжидайте смс-сообщения для окончательного подтверждения заказа.",
							"", JOptionPane.INFORMATION_MESSAGE);
					frame.setVisible(false);
				}
			}
		});
		frame.setSize(450, 600);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
