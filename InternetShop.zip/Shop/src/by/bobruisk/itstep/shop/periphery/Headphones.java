package by.bobruisk.itstep.shop.periphery;

public class Headphones {

	private String typeOf;
	private String connection;
	private String design;
	private String color;
	private String price;
	private String images[] = new String[3];
	private String name;

	public String getTypeOf() {
		return typeOf;
	}

	public void setTypeOf(String typeOf) {
		this.typeOf = typeOf;
	}

	public String getConnection() {
		return connection;
	}

	public void setConnection(String connection) {
		this.connection = connection;
	}

	public String getDesign() {
		return design;
	}

	public void setDesign(String design) {
		this.design = design;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String[] getImages() {
		return images;
	}

	public void setImages(String[] images) {
		this.images = images;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ\n")
				.append("---------------------------------------------------------------------------------\n").append("Название")
				.append(".........................................").append(this.name).append("\n").append("Тип")
				.append(".....................................................").append(this.typeOf).append("\n")
				.append("Подключение").append("..................................").append(this.connection)
				.append("\n").append("Констуркция").append(".....................................")
				.append(this.design).append("\n").append("Цвет")
				.append("....................................................").append(this.color).append("\n")
				.append("---------------------------------------------------------------------------------\n").append("Цена")
				.append("..................................................").append(this.price + "руб.");
		return str.toString();
	}
}
