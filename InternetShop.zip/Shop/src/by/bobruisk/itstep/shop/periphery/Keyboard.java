package by.bobruisk.itstep.shop.periphery;

public class Keyboard {

	private String typeOf;
	private String color;
	private String lengthOfCable;
	private String name;
	private String manufacturer;
	private String images[] = new String[3];
	private String price;

	public String getTypeOf() {
		return typeOf;
	}

	public void setTypeOf(String typeOf) {
		this.typeOf = typeOf;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getLengthOfCable() {
		return lengthOfCable;
	}

	public void setLengthOfCable(String lengthOfCable) {
		this.lengthOfCable = lengthOfCable;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String[] getImages() {
		return images;
	}

	public void setImages(String[] images) {
		this.images = images;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("ТЕХНИЧЕСКИЕ ХАРАКТЕРИСТИКИ\n")
				.append("---------------------------------------------------------------------\n")
				.append("Название").append(".........................................")
				.append(this.manufacturer).append(" ").append(this.name).append("\n").append("Тип")
				.append(".....................................................").append(this.typeOf).append("\n")
				.append("Длина кабеля").append(".................................")
				.append(this.lengthOfCable).append("\n").append("Цвет")
				.append("...................................................").append(this.color).append("\n")
				.append("----------------------------------------------------------------------\n")
				.append("Цена").append("..................................................").append(this.price + "руб.");
		return str.toString();
	}

}
