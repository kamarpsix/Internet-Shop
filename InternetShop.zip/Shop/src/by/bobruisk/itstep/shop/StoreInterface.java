package by.bobruisk.itstep.shop;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import by.bobruisk.itstep.shop.computer.Stock;

public class StoreInterface extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 70290335355326681L;
	Stock stock;

	public StoreInterface(Stock stock) {
		this.stock = stock;
	}

	public void createGUI() {
		JFrame frame = new JFrame("КОМПЬЮТЕР.бел");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Font font = new Font("Times", Font.CENTER_BASELINE, 16);
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenuOne = new JMenu("Игровые компьютеры");
		fileMenuOne.setFont(font);
		JMenu fileMenuTwo = new JMenu("Аксесуары и периферия");
		fileMenuTwo.setFont(font);
		JMenu fileMenuThree = new JMenu("Игровые ноутбуки");
		fileMenuThree.setFont(font);

		JMenu newMenuOne = new JMenu("До 1.200 руб.");
		newMenuOne.setFont(font);
		fileMenuOne.add(newMenuOne);
		JMenu newMenuTwo = new JMenu("От 1.200 до 1.800 руб.");
		newMenuTwo.setFont(font);
		fileMenuOne.add(newMenuTwo);
		JMenu newMenuThree = new JMenu("Клавиатуры");
		newMenuThree.setFont(font);
		fileMenuTwo.add(newMenuThree);
		JMenu newMenuFour = new JMenu("С экраном 15,6\"");
		newMenuFour.setFont(font);
		fileMenuThree.add(newMenuFour);
		JMenu newMenuFive = new JMenu("С экраном 17\"");
		newMenuFive.setFont(font);
		fileMenuThree.add(newMenuFive);
		JMenu newMenuSix = new JMenu("Наушники");
		newMenuSix.setFont(font);
		fileMenuTwo.add(newMenuSix);

		JMenuItem systemUnitOne = new JMenuItem(stock.computerOne.getName());
		systemUnitOne.setFont(font);
		newMenuOne.add(systemUnitOne);
		JMenuItem systemUnitTwo = new JMenuItem(stock.computerTwo.getName());
		systemUnitTwo.setFont(font);
		newMenuOne.add(systemUnitTwo);
		JMenuItem systemUnitThree = new JMenuItem(stock.computerThree.getName());
		systemUnitThree.setFont(font);
		newMenuOne.add(systemUnitThree);
		JMenuItem systemUnitFour = new JMenuItem(stock.computerFour.getName());
		systemUnitFour.setFont(font);
		newMenuTwo.add(systemUnitFour);
		JMenuItem systemUnitFive = new JMenuItem(stock.computerFive.getName());
		systemUnitFive.setFont(font);
		newMenuTwo.add(systemUnitFive);
		JMenuItem systemUnitSix = new JMenuItem(stock.computerSix.getName());
		systemUnitSix.setFont(font);
		newMenuTwo.add(systemUnitSix);

		JMenuItem keyboardOne = new JMenuItem(stock.keyboardOne.getManufacturer() + " " + stock.keyboardOne.getName());
		keyboardOne.setFont(font);
		newMenuThree.add(keyboardOne);
		JMenuItem keyboardTwo = new JMenuItem(stock.keyboardTwo.getManufacturer() + " " + stock.keyboardTwo.getName());
		keyboardTwo.setFont(font);
		newMenuThree.add(keyboardTwo);
		JMenuItem keyboardThree = new JMenuItem(
				stock.keyboardThree.getManufacturer() + " " + stock.keyboardThree.getName());
		keyboardThree.setFont(font);
		newMenuThree.add(keyboardThree);
		JMenuItem headphonesOne = new JMenuItem(stock.headphonesOne.getName());
		headphonesOne.setFont(font);
		newMenuSix.add(headphonesOne);
		JMenuItem headphonesTwo = new JMenuItem(stock.headphonesTwo.getName());
		headphonesTwo.setFont(font);
		newMenuSix.add(headphonesTwo);
		JMenuItem headphonesThree = new JMenuItem(stock.headphonesThree.getName());
		headphonesThree.setFont(font);
		newMenuSix.add(headphonesThree);

		JMenuItem laptopOne = new JMenuItem(stock.laptopOne.getName());
		laptopOne.setFont(font);
		newMenuFour.add(laptopOne);
		JMenuItem laptopTwo = new JMenuItem(stock.laptopTwo.getName());
		laptopTwo.setFont(font);
		newMenuFour.add(laptopTwo);
		JMenuItem laptopThree = new JMenuItem(stock.laptopThree.getName());
		laptopThree.setFont(font);
		newMenuFour.add(laptopThree);
		JMenuItem laptopFour = new JMenuItem(stock.laptopFour.getName());
		laptopFour.setFont(font);
		newMenuFive.add(laptopFour);

		JLabel label = new JLabel();
		label.setIcon(new ImageIcon("images/screensaver.jpg"));
		frame.add(label);

		menuBar.add(fileMenuOne);
		menuBar.add(fileMenuTwo);
		menuBar.add(fileMenuThree);
		frame.setJMenuBar(menuBar);

		frame.setPreferredSize(new Dimension(1366, 1024));
		frame.pack();
		frame.setLocationRelativeTo(null);

		systemUnitOne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerOne);
			}
		});

		systemUnitTwo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerTwo);

			}
		});

		systemUnitThree.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerThree);

			}
		});

		systemUnitFour.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerFour);

			}
		});

		systemUnitFive.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerFive);

			}
		});

		systemUnitSix.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				ComputerInformation productSelection = new ComputerInformation();
				productSelection.information(stock.computerSix);

			}
		});

		keyboardOne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				KeyboardInformation productSelection = new KeyboardInformation();
				productSelection.information(stock.keyboardOne);

			}
		});

		keyboardTwo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				KeyboardInformation productSelection = new KeyboardInformation();
				productSelection.information(stock.keyboardTwo);

			}
		});

		keyboardThree.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				KeyboardInformation productSelection = new KeyboardInformation();
				productSelection.information(stock.keyboardThree);

			}
		});

		laptopOne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LaptopInformation productSelection = new LaptopInformation();
				productSelection.information(stock.laptopOne);

			}
		});
		laptopTwo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LaptopInformation productSelection = new LaptopInformation();
				productSelection.information(stock.laptopTwo);

			}
		});

		laptopThree.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LaptopInformation productSelection = new LaptopInformation();
				productSelection.information(stock.laptopThree);

			}
		});

		laptopFour.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				LaptopInformation productSelection = new LaptopInformation();
				productSelection.information(stock.laptopFour);

			}
		});

		headphonesOne.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				HeadphoneInformation productSelection = new HeadphoneInformation();
				productSelection.information(stock.headphonesOne);

			}
		});

		headphonesTwo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				HeadphoneInformation productSelection = new HeadphoneInformation();
				productSelection.information(stock.headphonesTwo);

			}
		});

		headphonesThree.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				HeadphoneInformation productSelection = new HeadphoneInformation();
				productSelection.information(stock.headphonesThree);

			}
		});
		frame.setVisible(true);
	}
}
