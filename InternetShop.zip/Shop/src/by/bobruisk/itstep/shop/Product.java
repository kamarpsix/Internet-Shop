package by.bobruisk.itstep.shop;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.SpringLayout;

public abstract class Product {
	private ImageIcon[] images = new ImageIcon[3];
	private JFrame frame = new JFrame();
	private String task;
	private SpringLayout layout = new SpringLayout();

	public Product() {
		this.frame.setSize(1024, 720);
		this.frame.setLocationRelativeTo(null);
		this.frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.frame.setLayout(layout);
	}

	public ImageIcon[] loadPicture(String[] imageNames) {
		int length = imageNames.length;
		ImageIcon[] images = new ImageIcon[length];
		for (int i = 0; i < length; i++) {
			images[i] = new ImageIcon(imageNames[i]);
		}
		return images;
	}

	public ImageIcon[] getImages() {
		return images;
	}

	public void setImages(ImageIcon[] images) {
		this.images = images;
	}

	public JFrame getFrame() {
		return frame;
	}

	public void setFrame(JFrame frame) {
		this.frame = frame;
	}

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	public SpringLayout getLayout() {
		return layout;
	}

	public void setLayout(SpringLayout layout) {
		this.layout = layout;
	}
}
