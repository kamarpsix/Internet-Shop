package by.bobruisk.itstep.shop;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.SpringLayout;

import by.bobruisk.itstep.shop.periphery.Headphones;

public class HeadphoneInformation extends Product {

	public void information(Headphones headphones) {
		this.setTask("Наушники " + headphones.getName());
		JLabel task = new JLabel(this.getTask());
		JTextArea textField = new JTextArea(headphones.toString());
		this.getFrame().add(task);
		task.setFont(new Font("Bold", Font.BOLD, 28));
		this.getLayout().putConstraint(SpringLayout.WEST, task, 50, SpringLayout.WEST, this.getFrame());
		this.getLayout().putConstraint(SpringLayout.NORTH, task, 40, SpringLayout.NORTH, this.getFrame());
		this.setImages(this.loadPicture(headphones.getImages()));
		JLabel pictureOne = new JLabel(this.getImages()[0]);
		JLabel pictureTwo = new JLabel(this.getImages()[1]);
		JLabel pictureThree = new JLabel(this.getImages()[2]);
		JButton buy = new JButton("Оформить заказ");
		this.getFrame().add(pictureOne);
		this.getFrame().add(pictureTwo);
		this.getFrame().add(pictureThree);
		this.getFrame().add(textField);
		this.getFrame().add(buy);
		this.getLayout().putConstraint(SpringLayout.WEST, pictureOne, 50, SpringLayout.WEST, this.getFrame());
		this.getLayout().putConstraint(SpringLayout.NORTH, pictureOne, 100, SpringLayout.NORTH, this.getFrame());
		this.getLayout().putConstraint(SpringLayout.WEST, pictureTwo, 50, SpringLayout.EAST, pictureThree);
		this.getLayout().putConstraint(SpringLayout.NORTH, pictureTwo, 0, SpringLayout.NORTH, pictureOne);
		this.getLayout().putConstraint(SpringLayout.WEST, pictureThree, 50, SpringLayout.EAST, pictureOne);
		this.getLayout().putConstraint(SpringLayout.NORTH, pictureThree, 0, SpringLayout.NORTH, pictureOne);
		this.getLayout().putConstraint(SpringLayout.NORTH, textField, 30, SpringLayout.SOUTH, pictureOne);
		this.getLayout().putConstraint(SpringLayout.WEST, textField, 50, SpringLayout.WEST, this.getFrame());
		this.getLayout().putConstraint(SpringLayout.NORTH, buy, 30, SpringLayout.SOUTH, textField);
		this.getLayout().putConstraint(SpringLayout.WEST, buy, 33, SpringLayout.EAST, this.getFrame());

		buy.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Purchase purchase = new Purchase();
				purchase.purchase();
				getFrame().setVisible(false);
			}
		});
		this.getFrame().setVisible(true);
	}
}
